// Print a friendly greeting

package main

import (
	"fmt"
)

func main() {
	fmt.Println("Welcome Gophers ☺")
}
